This readme file contains approach taken to extract the relevant technologies corresponding to particuler job_title by utilizing the job description.

1.	input file    :       job_description.csv
		      :       technology.csv

2.	output 	      :       job_tech_1.csv
		      :       job_tech_2.csv


3. Approach :

After analyses of problem statement, input files and desired output, it seems to be  a text processing and retrieval task.

	

	3.1  :   technology.csv  : contains all unique technologies.
	
	3.2  : job_description.csv obseravtions : job_description.csv contains three columns 'company_name', 'job_title', 'job_desc' for this particuler problem
						 i have choosen 'job_title' and 'job_desc' as they only relevant to the task.
		
		1. 'job_title' contains redundent job_title (with different companies, with different requirements )
		2. 'job_title' contains same job_title with some variation in names such as :: 'system analyst' and 'systems analyst' 
		3. 'job_title' contains same profile with different name, such as :: 
											: backend developer --> back end developer
											: system engineer --> system developer/IT engineer
											: frontend developer --> frontend engineer/applicaation developer
		
		Removal of punctuations/name aliasing of same profile/variations in name types of problem has been tackled by using function 'preprocessing', 'alias_job_title'.
		Beacuase of that we have got a condensed ( multiple job grouped into one job title ) job_title name ('job_title_alias'). 

		4. 'job_desc' contains description of 'job_title', contains all technologies. 
		
		*** i have tracked down all technologies present in 'job_desc' which is also a part of  'technology.csv' using for loop over it. The only part remaining is how we 
		condensed all this extracted technologies for different alias of same job to a particuler condensed job title and that can be done by creating group with the help 
		of condensed job name transformed by function 'alias_job_title'.*** 

 											
	3.3 : we have created 2 output csv files 
		
		1. job_tech_1.csv  : contains technologies for each job title as described in probelm with no condensed form ( multiple job grouped into one job title ) of job_title.
		2. job_tech_1.csv  : contains technologies for each job title as described in probelm with condensed form ( multiple job grouped into one job title ) of job_title. 

4. Conclusion and Future work : In condensed form, i have identified 197 different job title. In future this file can be used to cluster technologies for particuler job_title and 
   can be used to develop ML model for the same.	
 

	